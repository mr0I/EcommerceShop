<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class metaproduct extends Model
{
    protected $guarded = [];
}
