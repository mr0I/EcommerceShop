<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/admin/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nymLZ5jX5Bnb3S4J',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard/articles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D9hrY2LsRwq06Q0r',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard/add_article' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JvTZkXNHkPzdfieR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/articles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'articles.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/articles/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/addArticle' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Wf4gzHCkmdixkGYY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/uploadArticleImage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7AVMDtsU9FsNrb02',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/deleteArticle' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4YBe2FQTRU9t6nnd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/restricted' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pxObAJJowqeg6mVQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/compare' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lRYcmF3zcA288Dyc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wishlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UbDZrSzefkywd7KY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminnnnlogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MdMRTPxxsea0e8MT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminCheckLogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DCruTGjSwicPgp3x',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tTpMCRKgO1HMFCRb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/storeComment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T1zcWgVKQSzxhrLe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/genSitemap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FErSenPv7yBTPcHn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zeNCjirbGZY4wJXJ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/authentication' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ful3aQQRD8uuUejR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mailTest' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YbBeJOViX5NX5QHa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sendTestMail' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GE1UFBiqdmhmSGof',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/my_account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AM5uAyj6i0CVgRxi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/my_account/wishlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Fj2NZED7z3gCVzU7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/my_account/changepassword' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dkKt3J2m5auN4lTM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dm-admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KjwH9wiynpBff6uf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/changeLang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y6KTp2dbmrKQTX9y',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/changeTheme' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RMVv3x8ttOUClGRW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/changeLayout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GWjq9XvdTguXARTZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/addToCompare' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OfHWuJTTJcbYXNtv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/addToWish' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XYtFAne0BfGdxf6r',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/removeFromCompare' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XjCPRax0Nr1Dbk76',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/removeFromWishList' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tbr76K7c0NLusFEo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/getProductInfo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5wYPchFgvFreVErX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/writeLog' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zgdKG8tmPaDVPgNf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/updateUserInfo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lQku0WkNj66U0C1e',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/updateUserPass' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g89YO2SGZmqYIHBm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S9Ieu1izky0GMfVG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OhKjTaUTCCsnLGzW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/confirm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bU3tFiPOKs5NZK54',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/a(?|dmin/(?|dashboard/edit_article/([^/]++)(*:51)|articles/([^/]++)(?|(*:78)|/edit(*:90)|(*:97))|updateArticle/([^/]++)(*:127))|rticle/([^/]++)(*:151))|/p(?|roduct/([^/]++)(*:180)|assword/reset/([^/]++)(*:210))|/category/([^/]++)(*:237)|/getCatProducts/([^/]++)(*:269)|/user/verify/([^/]++)(*:298))/?$}sDu',
    ),
    3 => 
    array (
      51 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wmpRlE15OMqVjx4b',
          ),
          1 => 
          array (
            0 => 'article_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      78 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.show',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      90 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.edit',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      97 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.update',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'articles.destroy',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      127 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Buo7KeY6ySGbIy2W',
          ),
          1 => 
          array (
            0 => 'article_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      151 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::F3EOBpzCqDMydN8Q',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      180 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pTOKUlDULvODvDzk',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      210 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      237 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ih3shw68YNjeC3Sl',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      269 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IatI0Em31SpsdeFG',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      298 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q4eEmIAG1zkXNSuo',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::nymLZ5jX5Bnb3S4J' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@index',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::nymLZ5jX5Bnb3S4J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::D9hrY2LsRwq06Q0r' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard/articles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@articles',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@articles',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::D9hrY2LsRwq06Q0r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::JvTZkXNHkPzdfieR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard/add_article',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@addArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@addArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::JvTZkXNHkPzdfieR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wmpRlE15OMqVjx4b' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard/edit_article/{article_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@editArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@editArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::wmpRlE15OMqVjx4b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@index',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@create',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/articles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@store',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@show',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles/{article}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@edit',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@update',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@destroy',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Wf4gzHCkmdixkGYY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/addArticle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@addArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@addArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Wf4gzHCkmdixkGYY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Buo7KeY6ySGbIy2W' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/updateArticle/{article_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@updateArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@updateArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Buo7KeY6ySGbIy2W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7AVMDtsU9FsNrb02' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/uploadArticleImage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@uploadArticleImage',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@uploadArticleImage',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::7AVMDtsU9FsNrb02',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4YBe2FQTRU9t6nnd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/deleteArticle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@deleteArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@deleteArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::4YBe2FQTRU9t6nnd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@index',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@index',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pTOKUlDULvODvDzk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@product',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@product',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::pTOKUlDULvODvDzk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pxObAJJowqeg6mVQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'restricted',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@restricted',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@restricted',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::pxObAJJowqeg6mVQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lRYcmF3zcA288Dyc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'compare',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@compare_products',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@compare_products',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::lRYcmF3zcA288Dyc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UbDZrSzefkywd7KY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'wishlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@wishlist',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@wishlist',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::UbDZrSzefkywd7KY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ih3shw68YNjeC3Sl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'category/{name}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@category',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@category',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ih3shw68YNjeC3Sl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MdMRTPxxsea0e8MT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminnnnlogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@adminLogin',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@adminLogin',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::MdMRTPxxsea0e8MT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DCruTGjSwicPgp3x' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminCheckLogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@adminCheckLogin',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@adminCheckLogin',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::DCruTGjSwicPgp3x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::F3EOBpzCqDMydN8Q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'article/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@singleArticle',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@singleArticle',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::F3EOBpzCqDMydN8Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tTpMCRKgO1HMFCRb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@blog',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@blog',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::tTpMCRKgO1HMFCRb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::T1zcWgVKQSzxhrLe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'storeComment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\CommentController@store',
        'controller' => 'App\\Http\\Controllers\\Site\\CommentController@store',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::T1zcWgVKQSzxhrLe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FErSenPv7yBTPcHn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'genSitemap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@genSitemap',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@genSitemap',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::FErSenPv7yBTPcHn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zeNCjirbGZY4wJXJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@search',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@search',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::zeNCjirbGZY4wJXJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ful3aQQRD8uuUejR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'authentication',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@authentication',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@authentication',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ful3aQQRD8uuUejR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YbBeJOViX5NX5QHa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mailTest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@mailTest',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@mailTest',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::YbBeJOViX5NX5QHa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GE1UFBiqdmhmSGof' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'sendTestMail',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@sendTestMail',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@sendTestMail',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::GE1UFBiqdmhmSGof',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AM5uAyj6i0CVgRxi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'my_account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'isAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@my_account',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@my_account',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::AM5uAyj6i0CVgRxi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Fj2NZED7z3gCVzU7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'my_account/wishlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'isAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@my_wishlist',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@my_wishlist',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Fj2NZED7z3gCVzU7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dkKt3J2m5auN4lTM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'my_account/changepassword',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'isAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@change_password',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@change_password',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::dkKt3J2m5auN4lTM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KjwH9wiynpBff6uf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dm-admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@admin_login',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@admin_login',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::KjwH9wiynpBff6uf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::y6KTp2dbmrKQTX9y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'changeLang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@changeLang',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@changeLang',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::y6KTp2dbmrKQTX9y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RMVv3x8ttOUClGRW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'changeTheme',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@changeTheme',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@changeTheme',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::RMVv3x8ttOUClGRW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GWjq9XvdTguXARTZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'changeLayout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@changeLayout',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@changeLayout',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::GWjq9XvdTguXARTZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OfHWuJTTJcbYXNtv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'addToCompare',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@addToCompare',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@addToCompare',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::OfHWuJTTJcbYXNtv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XYtFAne0BfGdxf6r' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'addToWish',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@addToWish',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@addToWish',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::XYtFAne0BfGdxf6r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XjCPRax0Nr1Dbk76' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'removeFromCompare',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromCompare',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromCompare',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::XjCPRax0Nr1Dbk76',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tbr76K7c0NLusFEo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'removeFromWishList',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromWishList',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromWishList',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::tbr76K7c0NLusFEo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::IatI0Em31SpsdeFG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getCatProducts/{name}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@getCatProducts',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@getCatProducts',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::IatI0Em31SpsdeFG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5wYPchFgvFreVErX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getProductInfo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@getProductInfo',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@getProductInfo',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::5wYPchFgvFreVErX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zgdKG8tmPaDVPgNf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'writeLog',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@writeLog',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@writeLog',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::zgdKG8tmPaDVPgNf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lQku0WkNj66U0C1e' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'updateUserInfo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserInfo',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserInfo',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::lQku0WkNj66U0C1e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::g89YO2SGZmqYIHBm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'updateUserPass',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserPass',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserPass',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::g89YO2SGZmqYIHBm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Q4eEmIAG1zkXNSuo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/verify/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@verifyUser',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@verifyUser',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Q4eEmIAG1zkXNSuo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::S9Ieu1izky0GMfVG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::S9Ieu1izky0GMfVG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OhKjTaUTCCsnLGzW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::OhKjTaUTCCsnLGzW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bU3tFiPOKs5NZK54' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bU3tFiPOKs5NZK54',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
