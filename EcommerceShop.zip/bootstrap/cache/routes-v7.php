<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/admin/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::56994HgpFWcZvwcG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard/articles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0I85ZvM0FgfyMzUF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard/add_article' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K0FoJt7hsA22uxk9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/articles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'articles.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/articles/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/addArticle' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G9OhEIifCoOYPQWq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/uploadArticleImage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OmLy0wNdoHgdK8zv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/deleteArticle' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JHsGRJriPjOe9PG6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/restricted' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::855YbpdUVkU3Usq3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wishlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KLysvCO5x86psHkj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminnnnlogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3R3QGaC3Qu2fxu5w',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminCheckLogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cAxZkF2tU11AWvFm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::c1e3dfKWKug8jtvG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/storeComment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5Y2LE7HoIAR05VRh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/genSitemap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JFSvBY2kn9gfanEs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zk0IfcHjwH1RMDX6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/authentication' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::B0inT6MuwGVXM3Cm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mailTest' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XRcAMlfgsVjEuYJR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sendTestMail' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YW6FaKs4jOczVBMb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/my_account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::udMvfqQqjlQWrvRN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/my_account/wishlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R6YMoBGihunsGB2h',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/my_account/changepassword' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0y70LijFFLWRZb8j',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dm-admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZjB9XYCRLm5E2wBY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/changeLang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8e53mIjznscvnk0v',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/changeTheme' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AkyoXsJNhSDxXxcM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/changeLayout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OaA6YwmHQZPMyPi4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/addToCompare' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YacxbIsXEKlNG59F',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/addToWish' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZGtT7Gxax9QYXRb1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/removeFromCompare' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2Hr40GtBge3digXm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/removeFromWishList' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nb6NBv2w9hg9r2kq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/getProductInfo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O985W1tlKWcSeGjr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/writeLog' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wn5w4LGbFS8kspW6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/updateUserInfo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T3f46oQrbDGIKcjt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/updateUserPass' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e1ZljX4kgOqpnFD0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/getProducts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gJewidCPbLUQAfoC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1RSjflx7PLdioJso',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ovrlNzCKrpWJVr7p',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/confirm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UYucQ9PFDK7M9DTp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/a(?|dmin/(?|dashboard/edit_article/([^/]++)(*:51)|articles/([^/]++)(?|(*:78)|/edit(*:90)|(*:97))|updateArticle/([^/]++)(*:127))|rticle/([^/]++)(*:151))|/p(?|roduct/([^/]++)(*:180)|assword/reset/([^/]++)(*:210))|/c(?|ompare(?:/([^/]++)(?:/([^/]++)(?:/([^/]++)(?:/([^/]++))?)?)?)?(*:286)|ategory/([^/]++)(*:310))|/getCatProducts/([^/]++)(*:343)|/user/verify/([^/]++)(*:372))/?$}sDu',
    ),
    3 => 
    array (
      51 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FNLrC2eqthXhyn9k',
          ),
          1 => 
          array (
            0 => 'article_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      78 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.show',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      90 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.edit',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      97 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.update',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'articles.destroy',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      127 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H5T2wYrtDyZpqvFs',
          ),
          1 => 
          array (
            0 => 'article_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      151 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Al9vzpGnj7ABd3sB',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      180 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wDBlAEJ7Oopnq3Hm',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      210 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      286 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OUTq5dU5h42Zidue',
            'pid1' => NULL,
            'pid2' => NULL,
            'pid3' => NULL,
            'pid4' => NULL,
          ),
          1 => 
          array (
            0 => 'pid1',
            1 => 'pid2',
            2 => 'pid3',
            3 => 'pid4',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      310 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5dK21owjkS2sBk3U',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      343 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::abplhSP9UbN4ECyF',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      372 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dV9zKjshVOkTFg4b',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::56994HgpFWcZvwcG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@index',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::56994HgpFWcZvwcG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0I85ZvM0FgfyMzUF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard/articles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@articles',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@articles',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::0I85ZvM0FgfyMzUF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::K0FoJt7hsA22uxk9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard/add_article',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@addArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@addArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::K0FoJt7hsA22uxk9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FNLrC2eqthXhyn9k' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard/edit_article/{article_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@editArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@editArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::FNLrC2eqthXhyn9k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@index',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@create',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/articles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@store',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@show',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles/{article}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@edit',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@update',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@destroy',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::G9OhEIifCoOYPQWq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/addArticle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@addArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@addArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::G9OhEIifCoOYPQWq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::H5T2wYrtDyZpqvFs' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/updateArticle/{article_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@updateArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@updateArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::H5T2wYrtDyZpqvFs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OmLy0wNdoHgdK8zv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/uploadArticleImage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@uploadArticleImage',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@uploadArticleImage',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::OmLy0wNdoHgdK8zv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::JHsGRJriPjOe9PG6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/deleteArticle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@deleteArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@deleteArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::JHsGRJriPjOe9PG6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@index',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@index',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wDBlAEJ7Oopnq3Hm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@product',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@product',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::wDBlAEJ7Oopnq3Hm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::855YbpdUVkU3Usq3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'restricted',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@restricted',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@restricted',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::855YbpdUVkU3Usq3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OUTq5dU5h42Zidue' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'compare/{pid1?}/{pid2?}/{pid3?}/{pid4?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@compare_products',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@compare_products',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::OUTq5dU5h42Zidue',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KLysvCO5x86psHkj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'wishlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@wishlist',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@wishlist',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::KLysvCO5x86psHkj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5dK21owjkS2sBk3U' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'category/{name}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@category',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@category',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::5dK21owjkS2sBk3U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3R3QGaC3Qu2fxu5w' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminnnnlogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@adminLogin',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@adminLogin',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::3R3QGaC3Qu2fxu5w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::cAxZkF2tU11AWvFm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminCheckLogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@adminCheckLogin',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@adminCheckLogin',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::cAxZkF2tU11AWvFm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Al9vzpGnj7ABd3sB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'article/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@singleArticle',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@singleArticle',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Al9vzpGnj7ABd3sB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::c1e3dfKWKug8jtvG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@blog',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@blog',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::c1e3dfKWKug8jtvG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5Y2LE7HoIAR05VRh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'storeComment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\CommentController@store',
        'controller' => 'App\\Http\\Controllers\\Site\\CommentController@store',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::5Y2LE7HoIAR05VRh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::JFSvBY2kn9gfanEs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'genSitemap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@genSitemap',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@genSitemap',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::JFSvBY2kn9gfanEs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zk0IfcHjwH1RMDX6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@search',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@search',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::zk0IfcHjwH1RMDX6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::B0inT6MuwGVXM3Cm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'authentication',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@authentication',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@authentication',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::B0inT6MuwGVXM3Cm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XRcAMlfgsVjEuYJR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mailTest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@mailTest',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@mailTest',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::XRcAMlfgsVjEuYJR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YW6FaKs4jOczVBMb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'sendTestMail',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@sendTestMail',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@sendTestMail',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::YW6FaKs4jOczVBMb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::udMvfqQqjlQWrvRN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'my_account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'isAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@my_account',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@my_account',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::udMvfqQqjlQWrvRN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::R6YMoBGihunsGB2h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'my_account/wishlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'isAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@my_wishlist',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@my_wishlist',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::R6YMoBGihunsGB2h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0y70LijFFLWRZb8j' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'my_account/changepassword',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'isAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@change_password',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@change_password',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::0y70LijFFLWRZb8j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZjB9XYCRLm5E2wBY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dm-admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@admin_login',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@admin_login',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ZjB9XYCRLm5E2wBY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8e53mIjznscvnk0v' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'changeLang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@changeLang',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@changeLang',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::8e53mIjznscvnk0v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AkyoXsJNhSDxXxcM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'changeTheme',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@changeTheme',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@changeTheme',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::AkyoXsJNhSDxXxcM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OaA6YwmHQZPMyPi4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'changeLayout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@changeLayout',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@changeLayout',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::OaA6YwmHQZPMyPi4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YacxbIsXEKlNG59F' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'addToCompare',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@addToCompare',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@addToCompare',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::YacxbIsXEKlNG59F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZGtT7Gxax9QYXRb1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'addToWish',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@addToWish',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@addToWish',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ZGtT7Gxax9QYXRb1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2Hr40GtBge3digXm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'removeFromCompare',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromCompare',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromCompare',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::2Hr40GtBge3digXm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nb6NBv2w9hg9r2kq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'removeFromWishList',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromWishList',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromWishList',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::nb6NBv2w9hg9r2kq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::abplhSP9UbN4ECyF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getCatProducts/{name}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@getCatProducts',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@getCatProducts',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::abplhSP9UbN4ECyF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::O985W1tlKWcSeGjr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getProductInfo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@getProductInfo',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@getProductInfo',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::O985W1tlKWcSeGjr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wn5w4LGbFS8kspW6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'writeLog',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@writeLog',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@writeLog',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::wn5w4LGbFS8kspW6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::T3f46oQrbDGIKcjt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'updateUserInfo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserInfo',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserInfo',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::T3f46oQrbDGIKcjt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::e1ZljX4kgOqpnFD0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'updateUserPass',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserPass',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserPass',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::e1ZljX4kgOqpnFD0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gJewidCPbLUQAfoC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getProducts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@getProducts',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@getProducts',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::gJewidCPbLUQAfoC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dV9zKjshVOkTFg4b' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/verify/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@verifyUser',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@verifyUser',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::dV9zKjshVOkTFg4b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1RSjflx7PLdioJso' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::1RSjflx7PLdioJso',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ovrlNzCKrpWJVr7p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ovrlNzCKrpWJVr7p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UYucQ9PFDK7M9DTp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::UYucQ9PFDK7M9DTp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
