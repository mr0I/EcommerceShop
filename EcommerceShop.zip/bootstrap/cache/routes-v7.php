<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/admin/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5HFmMcPdydLmpzMh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard/articles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SIa2MxZ41ttVmOpS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard/add_article' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yyxv4hlp4F4mqavF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/articles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'articles.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/articles/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/addArticle' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NX5gnbVYIfr6y35K',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/uploadArticleImage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C8u5fAQl4E22zw9W',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/deleteArticle' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xwVjRnuHVLbF6F7a',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/restricted' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iASOnW1rCp6kuzO8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/compare' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sh1lfT2w7U0EachO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wishlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m33QoNGG7BQf7EXP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminnnnlogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O8jorXYJqk51Lbwo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adminCheckLogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3fldzc7EkuRjdzNV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5JUQEcEjskYDiGFD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/storeComment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2265vpgeVWy2gxZb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/genSitemap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ajGU5Cgoy4bEDoiI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::I1zquUlbDm2G1q52',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/authentication' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2Q5SD8ywbMNqUbdC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/my_account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Oub318Ae8GI5MjAl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/my_account/wishlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FAknNhojedjq0pyS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/my_account/changepassword' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vxPzkAWaKsoQFtuQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dm-admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C9EySHtdJnePvLc0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/changeLang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3dqKyCL5MS5jKFhI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/changeTheme' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7qKSVjvS0GxWIggg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/changeLayout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XLZfVGRndp3Epx06',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/addToCompare' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jyQc6gHYTDTRJ58G',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/addToWish' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ogpQZ1ZQg3vwfOAv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/removeFromCompare' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hF50pEIkngXw7DZv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/removeFromWishList' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uzKULG5LWHFXiT7N',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/getProductInfo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yAsm1Ffb4lGjJMeo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/writeLog' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wrExM2nipzrt6sy3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/updateUserInfo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pHccELNME1Gg8R8F',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/updateUserPass' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XezwkSKz8nD4h7pR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3ymc8oR2peEuGzGb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4nl7KqssVOWiPXfv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/confirm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MxHDXCtBLBFsuUY3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/a(?|dmin/(?|dashboard/edit_article/([^/]++)(*:51)|articles/([^/]++)(?|(*:78)|/edit(*:90)|(*:97))|updateArticle/([^/]++)(*:127))|rticle/([^/]++)(*:151))|/p(?|roduct/([^/]++)(*:180)|assword/reset/([^/]++)(*:210))|/category/([^/]++)(*:237)|/getCatProducts/([^/]++)(*:269)|/user/verify/([^/]++)(*:298))/?$}sDu',
    ),
    3 => 
    array (
      51 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZSswmNMW06Jbl4in',
          ),
          1 => 
          array (
            0 => 'article_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      78 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.show',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      90 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.edit',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      97 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'articles.update',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'articles.destroy',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      127 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sRTC3RRmS5JfG9jL',
          ),
          1 => 
          array (
            0 => 'article_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      151 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qryyt9FskCa756J7',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      180 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dtkXt4G2L0YhJjCJ',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      210 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      237 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Xb9cWPy4pPQJCNJD',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      269 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W1lXDwBIiy6pL8rN',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      298 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yMt0Pe686pktm9f6',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::5HFmMcPdydLmpzMh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@index',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::5HFmMcPdydLmpzMh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SIa2MxZ41ttVmOpS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard/articles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@articles',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@articles',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::SIa2MxZ41ttVmOpS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yyxv4hlp4F4mqavF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard/add_article',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@addArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@addArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::yyxv4hlp4F4mqavF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZSswmNMW06Jbl4in' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard/edit_article/{article_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminContrller@editArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminContrller@editArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::ZSswmNMW06Jbl4in',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@index',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@create',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/articles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@store',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@show',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/articles/{article}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@edit',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@update',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'articles.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'as' => 'articles.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@destroy',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NX5gnbVYIfr6y35K' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/addArticle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@addArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@addArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::NX5gnbVYIfr6y35K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::sRTC3RRmS5JfG9jL' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/updateArticle/{article_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@updateArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@updateArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::sRTC3RRmS5JfG9jL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::C8u5fAQl4E22zw9W' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/uploadArticleImage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@uploadArticleImage',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@uploadArticleImage',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::C8u5fAQl4E22zw9W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xwVjRnuHVLbF6F7a' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/deleteArticle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'isAdmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArticleController@deleteArticle',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArticleController@deleteArticle',
        'namespace' => 'App\\Http\\Controllers\\Admin',
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::xwVjRnuHVLbF6F7a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@index',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@index',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dtkXt4G2L0YhJjCJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@product',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@product',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::dtkXt4G2L0YhJjCJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::iASOnW1rCp6kuzO8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'restricted',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@restricted',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@restricted',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::iASOnW1rCp6kuzO8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::sh1lfT2w7U0EachO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'compare',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@compare_products',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@compare_products',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::sh1lfT2w7U0EachO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::m33QoNGG7BQf7EXP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'wishlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@wishlist',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@wishlist',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::m33QoNGG7BQf7EXP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Xb9cWPy4pPQJCNJD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'category/{name}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@category',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@category',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Xb9cWPy4pPQJCNJD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::O8jorXYJqk51Lbwo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adminnnnlogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@adminLogin',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@adminLogin',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::O8jorXYJqk51Lbwo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3fldzc7EkuRjdzNV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adminCheckLogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@adminCheckLogin',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@adminCheckLogin',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::3fldzc7EkuRjdzNV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qryyt9FskCa756J7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'article/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@singleArticle',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@singleArticle',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::qryyt9FskCa756J7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5JUQEcEjskYDiGFD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@blog',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@blog',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::5JUQEcEjskYDiGFD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2265vpgeVWy2gxZb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'storeComment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\CommentController@store',
        'controller' => 'App\\Http\\Controllers\\Site\\CommentController@store',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::2265vpgeVWy2gxZb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ajGU5Cgoy4bEDoiI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'genSitemap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@genSitemap',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@genSitemap',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ajGU5Cgoy4bEDoiI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::I1zquUlbDm2G1q52' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@search',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@search',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::I1zquUlbDm2G1q52',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2Q5SD8ywbMNqUbdC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'authentication',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@authentication',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@authentication',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::2Q5SD8ywbMNqUbdC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Oub318Ae8GI5MjAl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'my_account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'isAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@my_account',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@my_account',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Oub318Ae8GI5MjAl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FAknNhojedjq0pyS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'my_account/wishlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'isAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@my_wishlist',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@my_wishlist',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::FAknNhojedjq0pyS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vxPzkAWaKsoQFtuQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'my_account/changepassword',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
          2 => 'isAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\SiteController@change_password',
        'controller' => 'App\\Http\\Controllers\\Site\\SiteController@change_password',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::vxPzkAWaKsoQFtuQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::C9EySHtdJnePvLc0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dm-admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@admin_login',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@admin_login',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::C9EySHtdJnePvLc0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3dqKyCL5MS5jKFhI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'changeLang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@changeLang',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@changeLang',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::3dqKyCL5MS5jKFhI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7qKSVjvS0GxWIggg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'changeTheme',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@changeTheme',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@changeTheme',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::7qKSVjvS0GxWIggg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XLZfVGRndp3Epx06' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'changeLayout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@changeLayout',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@changeLayout',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::XLZfVGRndp3Epx06',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jyQc6gHYTDTRJ58G' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'addToCompare',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@addToCompare',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@addToCompare',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::jyQc6gHYTDTRJ58G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ogpQZ1ZQg3vwfOAv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'addToWish',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@addToWish',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@addToWish',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ogpQZ1ZQg3vwfOAv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hF50pEIkngXw7DZv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'removeFromCompare',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromCompare',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromCompare',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::hF50pEIkngXw7DZv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uzKULG5LWHFXiT7N' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'removeFromWishList',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromWishList',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@removeFromWishList',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::uzKULG5LWHFXiT7N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::W1lXDwBIiy6pL8rN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getCatProducts/{name}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@getCatProducts',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@getCatProducts',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::W1lXDwBIiy6pL8rN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yAsm1Ffb4lGjJMeo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getProductInfo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@getProductInfo',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@getProductInfo',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::yAsm1Ffb4lGjJMeo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wrExM2nipzrt6sy3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'writeLog',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@writeLog',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@writeLog',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::wrExM2nipzrt6sy3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pHccELNME1Gg8R8F' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'updateUserInfo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserInfo',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserInfo',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::pHccELNME1Gg8R8F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XezwkSKz8nD4h7pR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'updateUserPass',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'XssSanitization',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserPass',
        'controller' => 'App\\Http\\Controllers\\Site\\IndexController@updateUserPass',
        'namespace' => 'App\\Http\\Controllers\\Site',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::XezwkSKz8nD4h7pR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yMt0Pe686pktm9f6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/verify/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@verifyUser',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@verifyUser',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::yMt0Pe686pktm9f6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3ymc8oR2peEuGzGb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::3ymc8oR2peEuGzGb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4nl7KqssVOWiPXfv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::4nl7KqssVOWiPXfv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MxHDXCtBLBFsuUY3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::MxHDXCtBLBFsuUY3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
