<!DOCTYPE html>
<html>
<head>
  <title>Welcome Email</title>
</head>

<body>
<h2>به سایت خوش آمدید </h2>
<br/>
ایمیل ثبت شده شما:
</body>

</html>